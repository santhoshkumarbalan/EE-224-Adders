# Optimized binary addition for a 64-bit adder
def binary_addition_nbit(a, b, carry_in=0):
    sum_value = a + b + carry_in
    sum_bin = sum_value & 0xFFFFFFFFFFFFFFFF  # 64-bit result
    carry_out = (sum_value >> 64) & 1  # Carry-out is the 33rd bit
    return sum_bin, carry_out

# Open file for writing directly
with open('64_bit_adder_tracefile_optimized.txt', 'w') as f:
    one_array = "111111111111111111111111111111111111111111111111111111111111111111"
    
    # Generating all possible 32-bit values for A, B and CarryIn
    for a in [17757453952154824133, 10182129845951896305, 13865740486791272332, 6537789880966252581, 8645739103104274035, 527421620055252396, 17293613363156507162, 13950800885633449568, 2639653370158137104, 7074259126428261784]:  # Upper limit can be adjusted based on memory
        for b in [17757453952154824133, 10182129845951896305, 13865740486791272332, 6537789880966252581, 8645739103104274035, 527421620055252396, 17293613363156507162, 13950800885633449568, 2639653370158137104, 7074259126428261784]:  # Limiting range to avoid too much processing time
            for carry_in in range(2):  # CarryIn can be 0 or 1
                sum_bin, carry_out = binary_addition_nbit(a, b, carry_in)
                
                # Directly format and write to file
                f.write(f"{a:064b}{b:064b}{carry_in} {sum_bin:064b}{carry_out} {one_array}\n")
    
print("Optimized trace file generated: 64_bit_adder_tracefile_optimized.txt")
