import random
list=[]
for i in range(10):
    list.append(random.randint(0,2**64-1))
print(list)
